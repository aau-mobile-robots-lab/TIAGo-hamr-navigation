# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.open_gl_buffer_object import OpenGLBufferObject


class OpenGLVertexBufferObject(OpenGLBufferObject):
    """
    OpenGLVertexBufferObject - no description provided.
    
    Superclass: OpenGLBufferObject
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkOpenGLVertexBufferObject, obj, update, **traits)
    
    data_type = traits.Int(0, auto_set=False, enter_set=True, desc=\
        """
        
        """
    )

    def _data_type_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetDataType,
                        self.data_type)

    stride = traits.Int(0, auto_set=False, enter_set=True, desc=\
        """
        
        """
    )

    def _stride_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetStride,
                        self.stride)

    def _get_coord_shift_and_scale_enabled(self):
        return self._vtk_obj.GetCoordShiftAndScaleEnabled()
    coord_shift_and_scale_enabled = traits.Property(_get_coord_shift_and_scale_enabled, desc=\
        """
        Get the shift and scale vectors computed by create_vbo; or set the
        values create_vbo and append_vbo will use. Note that the "Set"
        methods **must** be called before the first time that create_vbo
        or append_vbo is invoked and should never be called afterwards.
        
        The coord_shift_and_scale_method describes how the shift and scale
        vectors are obtained (or that they should never be used). The
        get_coord_shift_and_scale_enabled() method returns true if a shift and
        scale are currently being applied (or false if not).
        
        The "Get" methods are used by the mapper to modify the world and
        camera transformation matrices to match the scaling applied to
        coordinates in the VBO. create_vbo only applies a shift and scale
        when the midpoint of the point bounding-box is distant from the
        origin by a factor of 10,000 or more relative to the size of the
        box along any axis.
        
        For example, if the x coordinates of the points range from
        200,000 to 200,001 then the factor is 200,000.5 / (200,001 -
        200,000) = 2x10^5, which is larger than 10,000 -- so the
        coordinates will be shifted and scaled.
        
        This is important as many open_gl drivers use reduced precision to
        hold point coordinates.
        
        These methods are used by the mapper to determine the additional
        transform (if any) to apply to the rendering transform.
        """
    )

    def _get_data_type_size(self):
        return self._vtk_obj.GetDataTypeSize()
    data_type_size = traits.Property(_get_data_type_size, desc=\
        """
        
        """
    )

    def _get_number_of_components(self):
        return self._vtk_obj.GetNumberOfComponents()
    number_of_components = traits.Property(_get_number_of_components, desc=\
        """
        
        """
    )

    def _get_number_of_tuples(self):
        return self._vtk_obj.GetNumberOfTuples()
    number_of_tuples = traits.Property(_get_number_of_tuples, desc=\
        """
        
        """
    )

    def _get_upload_time(self):
        return wrap_vtk(self._vtk_obj.GetUploadTime())
    upload_time = traits.Property(_get_upload_time, desc=\
        """
        
        """
    )

    def append_data_array(self, *args):
        """
        V.append_data_array(DataArray)
        C++: void AppendDataArray(DataArray *array)"""
        my_args = deref_array(args, [['vtkDataArray']])
        ret = self._wrap_call(self._vtk_obj.AppendDataArray, *my_args)
        return ret

    def set_cache(self, *args):
        """
        V.set_cache(OpenGLVertexBufferObjectCache)
        C++: void SetCache(OpenGLVertexBufferObjectCache *cache)"""
        my_args = [deref_vtk(x) for x in args]
        ret = self._wrap_call(self._vtk_obj.SetCache, *my_args)
        return ret

    def upload_data_array(self, *args):
        """
        V.upload_data_array(DataArray)
        C++: void UploadDataArray(DataArray *array)"""
        my_args = deref_array(args, [['vtkDataArray']])
        ret = self._wrap_call(self._vtk_obj.UploadDataArray, *my_args)
        return ret

    def upload_vbo(self):
        """
        V.upload_vbo()
        C++: void UploadVBO()"""
        ret = self._vtk_obj.UploadVBO()
        return ret
        

    _updateable_traits_ = \
    (('debug', 'GetDebug'), ('reference_count', 'GetReferenceCount'),
    ('global_warning_display', 'GetGlobalWarningDisplay'), ('data_type',
    'GetDataType'), ('stride', 'GetStride'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['debug', 'global_warning_display', 'data_type', 'stride'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(OpenGLVertexBufferObject, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit OpenGLVertexBufferObject properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View(([], [], ['data_type', 'stride']),
            title='Edit OpenGLVertexBufferObject properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit OpenGLVertexBufferObject properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

